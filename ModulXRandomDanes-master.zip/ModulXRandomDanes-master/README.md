# ModulXRandomDanes

This project just contains some classes which can produce large numbers of 
random danes (name and phonenumber) and addresses which look kind of plausible.
